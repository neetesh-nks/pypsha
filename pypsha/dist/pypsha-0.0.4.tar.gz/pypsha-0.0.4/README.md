# PyPSHA

Package for regional probabilistic seismic hazard analysis

## Installation steps

1. Install Java to enable OpenSHA apps
2. Install cvxpy for optimization modules
3. pip install pypsha